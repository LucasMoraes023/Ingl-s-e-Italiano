const json = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff"
  },
  body: JSON.stringify(body)
});

export async function handler(event) {
  if (event.httpMethod !== "POST") {
    return json(405, { error: "Método não permitido." });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { error: "Mensagem inválida." });
  }

  const message = typeof payload.message === "string" ? payload.message.trim() : "";
  const language = payload.language === "it" ? "italiano" : "inglês";
  const level = typeof payload.level === "string" ? payload.level.slice(0, 12) : "A1";

  if (!message) return json(400, { error: "Escreva uma dúvida ou frase para praticar." });
  if (message.length > 1800) return json(413, { error: "Limite de 1800 caracteres por mensagem." });

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return json(503, {
      error: "O tutor de IA ainda não foi ativado neste site. Configure OPENAI_API_KEY nas variáveis de ambiente da hospedagem. As aulas e exercícios continuam disponíveis."
    });
  }

  const model = process.env.AI_MODEL || "gpt-4o-mini";
  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model,
        temperature: 0.5,
        max_tokens: 500,
        messages: [
          {
            role: "system",
            content: `Você é o tutor de idiomas do MAGO SUPREMO. Ensine ${language} para um falante de português brasileiro no nível ${level}. Responda em português claro quando explicar. Corrija com gentileza: mostre a forma natural, explique brevemente o motivo, dê no máximo dois exemplos e termine com uma pergunta ou exercício curto. Incentive o aluno a produzir frases. Não afirme que avaliou áudio se nenhum áudio foi enviado.`
          },
          { role: "user", content: message }
        ]
      })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      return json(response.status === 429 ? 429 : 502, {
        error: response.status === 429
          ? "O limite de uso da IA foi atingido. Tente mais tarde."
          : "Não foi possível obter resposta da IA. Verifique a configuração do provedor."
      });
    }

    const reply = data?.choices?.[0]?.message?.content?.trim();
    if (!reply) return json(502, { error: "A IA retornou uma resposta vazia. Tente novamente." });
    return json(200, { reply });
  } catch {
    return json(502, { error: "Falha de conexão com o serviço de IA. Tente novamente." });
  }
}