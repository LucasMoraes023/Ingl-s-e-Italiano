# MAGO SUPREMO — Language Academy

Plataforma web responsiva para estudar inglês e italiano, com trilha inicial A1, exercícios interativos, revisão de erros, metas de 45 minutos, progresso local, contas/sincronização opcional via Supabase e tutor de IA opcional via Netlify Function.

## O que funciona nesta versão

- Dois percursos separados: inglês e italiano.
- Aulas iniciais com frases úteis, tradução e dicas de pronúncia aproximada.
- Questões de múltipla escolha com feedback imediato.
- Marcação de aula concluída, pontos e acompanhamento de meta diária.
- Progresso salvo no aparelho automaticamente.
- Login, cadastro e recuperação de sessão com Supabase quando configurado.
- Sincronização do progresso do usuário autenticado via tabela protegida por RLS.
- Tutor de IA opcional via função de servidor. Sem chave, o tutor informa como ativá-lo; as aulas e exercícios continuam funcionando.
- Layout adaptado a celular e desktop.

## Requisitos

Node.js 20 ou superior recomendado e npm. Para usar somente pelo celular, é possível enviar a pasta a um ambiente que execute Node, ou publicar pelo GitHub/Netlify; a edição de arquivos é mais confortável em computador, mas não é obrigatória se usar um editor web.

## Rodar localmente

1. Instale Node.js.
2. Extraia o ZIP.
3. Na pasta do projeto, execute:
   ```bash
   npm install
   npm run dev
   ```
4. Abra o endereço mostrado pelo Vite.

## Contas e sincronização (Supabase gratuito)

1. Crie um projeto em https://supabase.com/.
2. No SQL Editor, execute `supabase/schema.sql`.
3. Em Project Settings → API, copie Project URL e a chave `anon`/publishable.
4. Crie `.env` copiando `.env.example` e preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
5. Reinicie `npm run dev`.

A chave pública anon pode estar no frontend; a segurança depende das políticas RLS. Nunca coloque a `service_role` no navegador. Em Authentication → URL Configuration, adicione seu domínio de desenvolvimento e o domínio de produção às URLs permitidas. Configure confirmação de e-mail conforme sua preferência e os recursos disponíveis no plano.

Sem Supabase configurado, o site usa modo local e mostra claramente que a sincronização não está ativa.

## Ativar tutor de IA (opcional)

1. Publique na Netlify.
2. Em Site configuration → Environment variables, defina `OPENAI_API_KEY` e, opcionalmente, `AI_MODEL` (padrão `gpt-4o-mini`).
3. Faça um novo deploy.
4. A função `netlify/functions/tutor.mjs` recebe a pergunta e chama o modelo do lado do servidor. A chave nunca é enviada ao navegador.

A API de IA pode gerar custos e não é garantidamente gratuita. Defina limites e monitore o uso no provedor. Sem a variável, as aulas continuam funcionais. O endpoint possui validação básica de tamanho e não deve ser considerado proteção completa contra abuso em um site público; antes de abrir para muitos usuários, implemente rate limiting por usuário/IP no gateway ou provedor.

## Publicar gratuitamente na Netlify

1. Envie o projeto para um repositório GitHub.
2. Na Netlify, importe o repositório.
3. Build command: `npm run build`; publish directory: `dist`. O `netlify.toml` já declara isso.
4. Configure as variáveis `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY` e, se for usar IA, `OPENAI_API_KEY`.
5. Publique e adicione o domínio de produção nas URLs permitidas do Supabase.

Também pode hospedar o frontend estático em outro provedor, mas a função de IA deste projeto requer um ambiente compatível com Netlify Functions ou adaptação equivalente.

## Conteúdo e metodologia

A trilha é uma base inicial A1 feita para este projeto, com vocabulário contextual, recuperação ativa, repetição e produção de frases. Não é um curso completo até C2 ainda. A estrutura permite adicionar módulos mantendo IDs estáveis. Pronúncias escritas são aproximações para falantes de português, não transcrição fonética exata nem avaliação automática da pronúncia.

## Limites conhecidos

- A IA é opcional e depende de chave/provedor com cota e disponibilidade.
- O reconhecimento de fala depende do navegador; esta versão não finge ter análise fonética avançada.
- O modo local usa o armazenamento do navegador e pode ser perdido se os dados do site forem apagados.
- O progresso sincronizado é salvo por conta com RLS. O mesmo usuário deve entrar para recuperar os dados em outro aparelho.
- Esta é uma primeira versão funcional, não uma alegação de fluência garantida nem uma certificação oficial CEFR.
