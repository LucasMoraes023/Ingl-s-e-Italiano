import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { createClient } from "@supabase/supabase-js";
import {
  Activity, ArrowLeft, ArrowRight, Award, BookOpen, Brain, Check,
  CheckCircle2, ChevronRight, CircleHelp, Clock3, Flame, Headphones,
  Languages, LockKeyhole, LogIn, LogOut, Menu, MessageCircle, Mic,
  Moon, RotateCcw, Send, Settings2, ShieldCheck, Sparkles, Target,
  Trophy, Volume2, X, Zap
} from "lucide-react";
import "./styles.css";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "";
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;

const courses = {
  en: {
    label: "Inglês", flag: "🇬🇧", subtitle: "English", color: "blue",
    lessons: [
      { id:"en-a1-01", title:"Apresente-se", unit:"Primeiros passos", minutes:8, level:"A1",
        goal:"Dizer seu nome e perguntar o nome de alguém.",
        words:[
          ["Hello","Olá","RÉ-lou"],["My name is…","Meu nome é…","mai NÊIM iz"],["What's your name?","Qual é o seu nome?","uóts iór NÊIM"],["Nice to meet you.","Prazer em conhecer você.","náis tchu MÍT iu"],["I'm from Brazil.","Eu sou do Brasil.","aim from brə-ZÍL"]
        ],
        explanation:"Em inglês, use “My name is…” para dizer seu nome. A forma contraída “I'm” significa “I am” (eu sou/estou).",
        dialogue:[["A","Hello! What's your name?"],["B","Hi! My name is Lucas."],["A","Nice to meet you, Lucas."],["B","Nice to meet you too!"]],
        questions:[
          {q:"Como você diz “Meu nome é Ana”?",options:["I name Ana.","My name is Ana.","Me name Ana."],correct:1,why:"A estrutura natural é “My name is + nome”."},
          {q:"O que significa “Nice to meet you”?",options:["Até amanhã","Como você está?","Prazer em conhecer você"],correct:2,why:"É uma expressão usada ao conhecer alguém."},
          {q:"Complete: “What's ___ name?”",options:["you","your","you're"],correct:1,why:"“Your” significa “seu/sua”: What's your name?"},
          {q:"Como dizer “Eu sou do Brasil”?",options:["I'm from Brazil.","I from Brazil.","I have Brazil."],correct:0,why:"Use “I'm from…” para falar de onde você é."}
        ]
      },
      { id:"en-a1-02", title:"Cumprimentos e gentileza", unit:"Primeiros passos", minutes:8, level:"A1",
        goal:"Cumprimentar, agradecer e pedir algo educadamente.",
        words:[["Good morning","Bom dia","gud MÓR-ning"],["Please","Por favor","plíz"],["Thank you","Obrigado(a)","thénk iu"],["You're welcome","De nada","iór UÉL-kam"],["Excuse me","Com licença","ik-SKIUZ mi"]],
        explanation:"“Please” deixa pedidos mais educados. “Excuse me” chama a atenção ou pede passagem; “I'm sorry” é usado para pedir desculpas.",
        dialogue:[["A","Good morning!"],["B","Good morning! How are you?"],["A","I'm good, thank you."],["B","You're welcome!"]],
        questions:[
          {q:"Qual expressão significa “Por favor”?",options:["Please","Sorry","Welcome"],correct:0,why:"“Please” é usado em pedidos educados."},
          {q:"Você quer passar por alguém. O que diz?",options:["Good night","Excuse me","Thank you"],correct:1,why:"“Excuse me” pode significar “com licença”."},
          {q:"“Thank you” significa…",options:["Desculpe","Por favor","Obrigado(a)"],correct:2,why:"É uma expressão de agradecimento."}
        ]
      },
      { id:"en-a1-03", title:"Falar sobre sua rotina", unit:"Vida cotidiana", minutes:10, level:"A1",
        goal:"Dizer frases simples sobre hábitos diários.",
        words:[["I work","Eu trabalho","ai uârk"],["I study","Eu estudo","ai STÂ-di"],["Every day","Todos os dias","É-vri dêi"],["In the morning","De manhã","in dhə MÓR-ning"],["At night","À noite","ét náit"]],
        explanation:"No presente simples, “I work” significa “eu trabalho”. Com he/she/it, muitos verbos recebem -s: “She works”.",
        dialogue:[["A","What do you do every day?"],["B","I work and I study English."],["A","When do you study?"],["B","I study at night."]],
        questions:[
          {q:"Como dizer “Eu estudo inglês”?",options:["I studies English.","I study English.","I studying English."],correct:1,why:"Com “I”, use o verbo na forma base: study."},
          {q:"Complete: “She ___ every day.”",options:["work","working","works"],correct:2,why:"No presente simples, he/she/it geralmente recebe -s."},
          {q:"“At night” significa…",options:["De manhã","À noite","Toda semana"],correct:1,why:"“At night” é “à noite”."}
        ]
      },
      { id:"en-a1-04", title:"Pedir comida e bebida", unit:"Vida cotidiana", minutes:10, level:"A1",
        goal:"Fazer um pedido simples em um café.",
        words:[["I'd like…","Eu gostaria de…","aid láik"],["Water","Água","UÓ-ter"],["Coffee","Café","KÓ-fi"],["The bill, please","A conta, por favor","dhə bil plíz"],["How much is it?","Quanto custa?","ráu match iz it"]],
        explanation:"“I'd like…” é uma maneira educada de pedir algo. Exemplo: “I'd like a coffee, please.”",
        dialogue:[["A","Hello. What would you like?"],["B","I'd like a coffee, please."],["A","Anything else?"],["B","No, thank you."]],
        questions:[
          {q:"Como pedir um café educadamente?",options:["I want coffee now!","I'd like a coffee, please.","Coffee you give."],correct:1,why:"“I'd like… please” é natural e educado."},
          {q:"Como perguntar o preço?",options:["How old is it?","How much is it?","How many are you?"],correct:1,why:"“How much is it?” pergunta quanto custa."},
          {q:"“Water” significa…",options:["Vinho","Leite","Água"],correct:2,why:"Water = água."}
        ]
      }
    ]
  },
  it: {
    label: "Italiano", flag: "🇮🇹", subtitle: "Italiano", color: "green",
    lessons: [
      { id:"it-a1-01", title:"Apresente-se", unit:"Primi passi", minutes:8, level:"A1",
        goal:"Dizer seu nome e conhecer alguém.",
        words:[["Ciao!","Oi! / Tchau!","tcháu"],["Mi chiamo…","Meu nome é…","mi KIÁ-mo"],["Come ti chiami?","Como você se chama?","KÔ-me ti KIÁ-mi"],["Piacere!","Prazer!","pia-TCHÊ-re"],["Sono brasiliano/a.","Sou brasileiro/a.","SÔ-no bra-zi-liÁ-no/a"]],
        explanation:"“Mi chiamo…” significa literalmente “eu me chamo…”. Em italiano, “ciao” é informal e pode ser usado ao chegar ou se despedir.",
        dialogue:[["A","Ciao! Come ti chiami?"],["B","Ciao! Mi chiamo Luca."],["A","Piacere, Luca!"],["B","Piacere!"]],
        questions:[
          {q:"Como dizer “Meu nome é Maria”?",options:["Mi nome Maria.","Mi chiamo Maria.","Sono chiamo Maria."],correct:1,why:"A expressão correta é “Mi chiamo Maria”."},
          {q:"“Piacere!” significa…",options:["Prazer!","Por favor!","Boa noite!"],correct:0,why:"Usamos “Piacere” ao conhecer alguém."},
          {q:"“Come ti chiami?” pergunta…",options:["Onde você mora?","Como você se chama?","Quantos anos você tem?"],correct:1,why:"É a pergunta informal sobre o nome."},
          {q:"Qual é uma saudação informal?",options:["Ciao!","Grazie!","Scusa!"],correct:0,why:"“Ciao” é um cumprimento informal."}
        ]
      },
      { id:"it-a1-02", title:"Cumprimentos e educação", unit:"Primi passi", minutes:8, level:"A1",
        goal:"Cumprimentar e agradecer.",
        words:[["Buongiorno","Bom dia","buon-DJÓR-no"],["Per favore","Por favor","per fa-VÔ-re"],["Grazie","Obrigado(a)","GRÁ-tsie"],["Prego","De nada / Pois não","PRÊ-go"],["Scusi","Com licença (formal)","SKÚ-zi"]],
        explanation:"“Grazie” é obrigado(a). “Prego” pode significar “de nada”. “Scusi” é uma forma educada/formal de chamar a atenção.",
        dialogue:[["A","Buongiorno!"],["B","Buongiorno. Un caffè, per favore."],["A","Certo. Ecco a Lei."],["B","Grazie!"],["A","Prego!"]],
        questions:[
          {q:"Como dizer “obrigado(a)”?",options:["Prego","Grazie","Scusi"],correct:1,why:"“Grazie” significa obrigado(a)."},
          {q:"“Per favore” significa…",options:["Por favor","Até logo","Desculpe"],correct:0,why:"É a expressão italiana para “por favor”."},
          {q:"Uma resposta comum a “Grazie” é…",options:["Prego","Buongiorno","Arrivederci"],correct:0,why:"“Prego” pode ser usado como “de nada”."}
        ]
      },
      { id:"it-a1-03", title:"Sua rotina", unit:"Vita quotidiana", minutes:10, level:"A1",
        goal:"Falar sobre trabalho e estudo.",
        words:[["Lavoro","Eu trabalho","la-VÔ-ro"],["Studio","Eu estudo","STÚ-dio"],["Ogni giorno","Todos os dias","Ô-nhi DJÓR-no"],["La mattina","De manhã","la mat-TÍ-na"],["La sera","À noite / no fim do dia","la SÊ-ra"]],
        explanation:"Em italiano, a terminação do verbo muitas vezes já indica a pessoa. “Lavoro” = eu trabalho; “studio” = eu estudo.",
        dialogue:[["A","Che cosa fai ogni giorno?"],["B","Lavoro e studio italiano."],["A","Quando studi?"],["B","Studio la sera."]],
        questions:[
          {q:"“Studio italiano” significa…",options:["Eu ensino italiano","Eu estudo italiano","Eu falo italiano perfeitamente"],correct:1,why:"“Studio” significa “eu estudo”."},
          {q:"“Ogni giorno” significa…",options:["Todos os dias","No próximo ano","Às vezes"],correct:0,why:"É a expressão para “todos os dias”."},
          {q:"Como dizer “Eu trabalho”?",options:["Lavoro","Lavori","Lavorano"],correct:0,why:"“Lavoro” é a forma de primeira pessoa singular."}
        ]
      },
      { id:"it-a1-04", title:"No café", unit:"Vita quotidiana", minutes:10, level:"A1",
        goal:"Pedir algo em um café italiano.",
        words:[["Vorrei…","Eu gostaria de…","vor-RÊI"],["Un caffè","Um café espresso","un kaf-FÉ"],["Acqua","Água","ÁK-kua"],["Il conto, per favore","A conta, por favor","il KÔN-to per fa-VÔ-re"],["Quanto costa?","Quanto custa?","KUAN-to KÓS-ta"]],
        explanation:"“Vorrei…” é uma forma educada para pedir algo. Na Itália, “un caffè” normalmente se refere a um espresso.",
        dialogue:[["A","Buongiorno, desidera?"],["B","Vorrei un caffè, per favore."],["A","Altro?"],["B","No, grazie."]],
        questions:[
          {q:"Como pedir educadamente um café?",options:["Dammi caffè!","Vorrei un caffè, per favore.","Io caffè adesso."],correct:1,why:"“Vorrei… per favore” é uma forma educada."},
          {q:"“Acqua” significa…",options:["Água","Café","Conta"],correct:0,why:"Acqua = água."},
          {q:"Como perguntar “Quanto custa?”",options:["Quanti anni?","Quanto costa?","Come ti chiami?"],correct:1,why:"“Quanto costa?” é a pergunta sobre preço."}
        ]
      }
    ]
  }
};

const defaultProgress = () => ({
  completed: [], mistakes: {}, streak: 0, lastStudyDate: null, dailyMinutes: 0,
  points: 0, answers: 0, correct: 0, history: {}
});
const STORAGE_KEY = "mago-supremo-progress-v1";
const todayKey = () => new Date().toLocaleDateString("en-CA");
const safeParse = (value, fallback) => { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } };

function App() {
  const [language, setLanguage] = useState("en");
  const [progress, setProgress] = useState(() => ({...defaultProgress(), ...safeParse(localStorage.getItem(STORAGE_KEY), {})}));
  const [user, setUser] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMessage, setAuthMessage] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [activeLesson, setActiveLesson] = useState(null);
  const [view, setView] = useState("home");
  const [answers, setAnswers] = useState({});
  const [tutorText, setTutorText] = useState("");
  const [tutorReply, setTutorReply] = useState("");
  const [tutorBusy, setTutorBusy] = useState(false);
  const [tutorError, setTutorError] = useState("");
  const [tutorMode, setTutorMode] = useState("teacher");
  const [mobileNav, setMobileNav] = useState(false);
  const [notice, setNotice] = useState("");
  const course = courses[language];
  const allLessons = useMemo(() => Object.values(courses).flatMap(c => c.lessons), []);
  const lesson = allLessons.find(l => l.id === activeLesson);
  const completedCount = progress.completed.length;
  const totalLessons = allLessons.length;
  const accuracy = progress.answers ? Math.round((progress.correct / progress.answers) * 100) : 0;
  const todayMinutes = progress.history?.[todayKey()]?.minutes || 0;

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
    const {data: listener} = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!supabase || !user) return;
    let cancelled = false;
    (async () => {
      const {data, error} = await supabase.from("user_progress").select("progress").eq("user_id", user.id).maybeSingle();
      if (cancelled) return;
      if (error) { setNotice("Não foi possível carregar a nuvem. Seu progresso local continua salvo."); return; }
      if (data?.progress) {
        const local = safeParse(localStorage.getItem(STORAGE_KEY), defaultProgress());
        const cloud = data.progress;
        const merged = {
          ...defaultProgress(), ...local, ...cloud,
          completed: [...new Set([...(local.completed || []), ...(cloud.completed || [])])],
          mistakes: {...(local.mistakes || {}), ...(cloud.mistakes || {})},
          history: {...(local.history || {}), ...(cloud.history || {})}
        };
        setProgress(merged);
      } else {
        const {error: insertError} = await supabase.from("user_progress").insert({user_id:user.id, progress});
        if (insertError && !cancelled) setNotice("Conta conectada; a tabela de progresso ainda precisa ser configurada no Supabase.");
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id]);

  useEffect(() => {
    if (!supabase || !user) return;
    const timer = setTimeout(async () => {
      const {error} = await supabase.from("user_progress").upsert({
        user_id: user.id, progress, updated_at: new Date().toISOString()
      }, {onConflict:"user_id"});
      if (error) setNotice("Progresso salvo neste aparelho; a sincronização encontrou um problema.");
    }, 700);
    return () => clearTimeout(timer);
  }, [progress, user?.id]);

  function recordActivity(minutes = 1) {
    const today = todayKey();
    setProgress(p => {
      const history = {...p.history};
      const day = {...(history[today] || {minutes:0, answers:0, correct:0})};
      day.minutes += minutes;
      history[today] = day;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yKey = yesterday.toLocaleDateString("en-CA");
      const streak = p.lastStudyDate === today ? p.streak : p.lastStudyDate === yKey ? p.streak + 1 : 1;
      return {...p, history, dailyMinutes: day.minutes, lastStudyDate: today, streak};
    });
  }

  function openLesson(id) {
    setActiveLesson(id);
    setAnswers({});
    setView("lesson");
    setMobileNav(false);
    window.scrollTo({top:0,behavior:"smooth"});
  }

  function answerQuestion(qIndex, optionIndex) {
    if (answers[qIndex] !== undefined) return;
    const q = lesson.questions[qIndex];
    const isCorrect = q.correct === optionIndex;
    setAnswers(a => ({...a, [qIndex]: optionIndex}));
    setProgress(p => ({
      ...p,
      answers: p.answers + 1,
      correct: p.correct + (isCorrect ? 1 : 0),
      points: p.points + (isCorrect ? 10 : 2),
      mistakes: isCorrect ? p.mistakes : {...p.mistakes, [lesson.id]: (p.mistakes[lesson.id] || 0) + 1}
    }));
    recordActivity(1);
  }

  function completeLesson() {
    if (!lesson) return;
    setProgress(p => ({...p, completed: [...new Set([...p.completed, lesson.id])], points: p.points + 20}));
    recordActivity(Math.max(1, lesson.minutes - Object.keys(answers).length));
    setNotice("Aula concluída! +20 pontos. Continue praticando! ✨");
    setView("home");
    setActiveLesson(null);
  }

  async function submitAuth(e) {
    e.preventDefault();
    if (!supabase) {
      setAuthMessage("Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY para ativar contas e sincronização. O modo local já funciona.");
      return;
    }
    setAuthBusy(true); setAuthMessage("");
    try {
      if (authMode === "signup") {
        const {error} = await supabase.auth.signUp({email, password});
        if (error) throw error;
        setAuthMessage("Cadastro enviado. Se a confirmação de e-mail estiver ativa, confira sua caixa de entrada.");
      } else if (authMode === "reset") {
        const {error} = await supabase.auth.resetPasswordForEmail(email, {redirectTo: window.location.origin});
        if (error) throw error;
        setAuthMessage("Se o endereço estiver cadastrado, você receberá instruções para redefinir a senha.");
      } else {
        const {error} = await supabase.auth.signInWithPassword({email, password});
        if (error) throw error;
        setAuthOpen(false);
      }
    } catch (err) {
      setAuthMessage(err.message || "Não foi possível concluir a autenticação.");
    } finally { setAuthBusy(false); }
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
    setUser(null);
    setNotice("Você saiu da conta. O progresso local permanece neste aparelho.");
  }

  async function askTutor(e) {
    e.preventDefault();
    if (!tutorText.trim()) return;
    setTutorBusy(true); setTutorError(""); setTutorReply("");
    try {
      const response = await fetch("/api/tutor", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({message:tutorText.trim(), language, level: lesson?.level || "A1", mode:tutorMode})
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Não foi possível responder.");
      setTutorReply(data.reply);
      recordActivity(2);
    } catch (err) {
      setTutorError(err.message || "O tutor de IA precisa estar publicado e configurado. Você ainda pode praticar com as aulas.");
    } finally { setTutorBusy(false); }
  }

  const speak = (text) => {
    if (!("speechSynthesis" in window)) {
      setNotice("Este navegador não oferece leitura de voz compatível.");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === "en" ? "en-US" : "it-IT";
    utterance.rate = 0.86;
    window.speechSynthesis.speak(utterance);
  };

  const navigate = (next) => { setView(next); setActiveLesson(null); setMobileNav(false); window.scrollTo({top:0,behavior:"smooth"}); };
  const greeting = new Intl.DateTimeFormat("pt-BR", {hour:"numeric"}).format(new Date());
  const hour = new Date().getHours();
  const greetingText = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={23}/></div>
          <div><strong>MAGO <span>SUPREMO</span></strong><small>LANGUAGE ACADEMY</small></div>
          <button className="icon-btn mobile-close" onClick={()=>setMobileNav(false)} aria-label="Fechar menu"><X size={20}/></button>
        </div>
        <div className="sidebar-label">ACADEMIA</div>
        <nav className="nav-list">
          <button className={view==="home" ? "nav-item active" : "nav-item"} onClick={()=>navigate("home")}><Activity size={18}/> Visão geral</button>
          <button className={view==="courses" ? "nav-item active" : "nav-item"} onClick={()=>navigate("courses")}><BookOpen size={18}/> Meus cursos</button>
          <button className={view==="review" ? "nav-item active" : "nav-item"} onClick={()=>navigate("review")}><RotateCcw size={18}/> Revisão inteligente</button>
          <button className={view==="tutor" ? "nav-item active" : "nav-item"} onClick={()=>navigate("tutor")}><Brain size={18}/> Professor de IA <span className="nav-new">BETA</span></button>
        </nav>
        <div className="sidebar-label language-label">SEUS IDIOMAS</div>
        <button className={`language-switch ${language==="en"?"selected":""}`} onClick={()=>{setLanguage("en");navigate("courses")}}><span className="flag">🇬🇧</span><span><b>Inglês</b><small>English · A1</small></span>{language==="en"&&<Check size={16}/>}</button>
        <button className={`language-switch ${language==="it"?"selected":""}`} onClick={()=>{setLanguage("it");navigate("courses")}}><span className="flag">🇮🇹</span><span><b>Italiano</b><small>Italiano · A1</small></span>{language==="it"&&<Check size={16}/>}</button>
        <div className="sidebar-bottom">
          <div className="sidebar-tip"><div className="tip-icon"><Zap size={16}/></div><b>Pequenos passos.</b><p>45 minutos por dia podem transformar sua jornada.</p></div>
          {user ? <button className="account-btn" onClick={signOut}><LogOut size={17}/><span><b>{user.email}</b><small>Sair da conta</small></span></button> :
            <button className="account-btn" onClick={()=>{setAuthOpen(true);setAuthMode("login")}}><div className="avatar">MS</div><span><b>Minha conta</b><small>{supabase ? "Entrar ou cadastrar" : "Sincronização não configurada"}</small></span><ChevronRight size={16}/></button>}
        </div>
      </aside>

      {mobileNav && <button className="scrim" onClick={()=>setMobileNav(false)} aria-label="Fechar menu"/>}

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-btn mobile-menu" onClick={()=>setMobileNav(true)} aria-label="Abrir menu"><Menu size={21}/></button>
            <div className="breadcrumb">MAGO SUPREMO <ChevronRight size={14}/> <span>{({home:"Visão geral",courses:"Meus cursos",review:"Revisão inteligente",tutor:"Professor de IA",lesson:"Aula"})[view] || "Academia"}</span></div>
          </div>
          <div className="topbar-right">
            <div className="today-pill"><span className="online-dot"/>{user ? "Conta sincronizada" : "Modo de demonstração local"}</div>
            <button className="profile-button" onClick={()=>{setAuthOpen(true);setAuthMode("login")}} aria-label="Conta"><span className="avatar">{user ? (user.email?.[0]||"U").toUpperCase() : "MS"}</span></button>
          </div>
        </header>

        {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice("")} aria-label="Fechar aviso"><X size={16}/></button></div>}

        {view==="home" && <div className="page-content">
          <section className="welcome-row">
            <div><div className="eyebrow"><span className="eyebrow-line"/> SEU PRÓXIMO NÍVEL COMEÇA AQUI</div><h1>{greetingText}{user?.email ? `, ${user.email.split("@")[0]}` : ""}! <span className="wave">✦</span></h1><p className="lead">Cada palavra aprendida é um passo rumo à fluência. Vamos praticar?</p></div>
            <div className="date-label"><Clock3 size={15}/>{new Intl.DateTimeFormat("pt-BR",{weekday:"long",day:"numeric",month:"long"}).format(new Date())}</div>
          </section>

          <section className="hero-card">
            <div className="hero-glow"/><div className="hero-content">
              <div className="hero-tag"><Sparkles size={14}/> SUA MISSÃO DE HOJE</div>
              <h2>O segredo é<br/><em>praticar todos os dias.</em></h2>
              <p>45 minutos de prática ativa. Um pouco de escuta, vocabulário e conversação faz diferença quando você mantém a constância.</p>
              <button className="primary-btn" onClick={()=>openLesson(course.lessons.find(l=>!progress.completed.includes(l.id))?.id || course.lessons[0].id)}>Continuar aprendendo <ArrowRight size={17}/></button>
            </div>
            <div className="hero-art" aria-hidden="true"><div className="orb orb-one"/><div className="orb orb-two"/><div className="book-illustration"><BookOpen size={74} strokeWidth={1.1}/><span>ABC</span></div><div className="floating-word word-one">Hello!</div><div className="floating-word word-two">Ciao!</div><div className="floating-star star-one">✦</div><div className="floating-star star-two">✧</div></div>
          </section>

          <section className="stats-grid">
            <Stat icon={<Target size={19}/>} label="Meta de hoje" value={`${Math.min(todayMinutes,45)}/45 min`} foot={`${Math.max(0,45-todayMinutes)} min para sua meta`} progress={Math.min(100,todayMinutes/45*100)} tone="gold"/>
            <Stat icon={<Flame size={19}/>} label="Sequência" value={`${progress.streak} ${progress.streak===1?"dia":"dias"}`} foot="Continue no seu ritmo" tone="orange"/>
            <Stat icon={<Trophy size={19}/>} label="Pontos conquistados" value={progress.points.toLocaleString("pt-BR")} foot="Aprender vale a pena" tone="purple"/>
            <Stat icon={<Activity size={19}/>} label="Precisão nos testes" value={`${accuracy}%`} foot={`${progress.correct} respostas corretas`} progress={accuracy} tone="green"/>
          </section>

          <section className="section-block">
            <div className="section-heading"><div><div className="eyebrow">SEU PLANO DE ESTUDO</div><h2>Escolha seu próximo passo</h2></div><button className="text-btn" onClick={()=>navigate("courses")}>Ver todos os cursos <ArrowRight size={16}/></button></div>
            <div className="course-grid">
              <CourseCard language="en" course={courses.en} progress={progress} onSelect={()=>{setLanguage("en");navigate("courses")}}/>
              <CourseCard language="it" course={courses.it} progress={progress} onSelect={()=>{setLanguage("it");navigate("courses")}}/>
            </div>
          </section>

          <section className="bottom-grid">
            <div className="panel">
              <div className="panel-heading"><div><div className="eyebrow">PRÓXIMA ATIVIDADE</div><h3>Seu treino recomendado</h3></div><div className="panel-icon"><Brain size={20}/></div></div>
              <div className="recommended-row"><div className="activity-icon"><MessageCircle size={21}/></div><div className="activity-copy"><b>Pratique uma apresentação</b><p>Treine como dizer seu nome e conhecer alguém.</p><span><Clock3 size={13}/> 8 minutos · A1</span></div><button className="round-arrow" onClick={()=>openLesson(course.lessons[0].id)} aria-label="Iniciar atividade"><ArrowRight size={18}/></button></div>
            </div>
            <div className="panel quote-panel"><div className="quote-mark">“</div><p>Uma nova língua é uma nova maneira de ver o mundo.</p><span>SEU LEMBRETE DE HOJE</span><div className="quote-spark">✦</div></div>
          </section>
          <footer>MAGО SUPREMO <span>•</span> Aprenda no seu ritmo. Evolua todos os dias.</footer>
        </div>}

        {view==="courses" && <div className="page-content">
          <section className="page-intro"><div className="eyebrow"><span className="eyebrow-line"/> APRENDA NA PRÁTICA</div><h1>Seus cursos</h1><p className="lead">Aulas curtas, vocabulário útil e exercícios para construir sua confiança.</p></section>
          <div className="tabs"><button className={language==="en"?"tab active":"tab"} onClick={()=>setLanguage("en")}>🇬🇧 Inglês <span>{courses.en.lessons.filter(l=>progress.completed.includes(l.id)).length}/{courses.en.lessons.length}</span></button><button className={language==="it"?"tab active":"tab"} onClick={()=>setLanguage("it")}>🇮🇹 Italiano <span>{courses.it.lessons.filter(l=>progress.completed.includes(l.id)).length}/{courses.it.lessons.length}</span></button></div>
          <div className="course-banner"><div className="course-banner-flag">{course.flag}</div><div><span className="eyebrow">{course.subtitle.toUpperCase()} · NÍVEL A1</span><h2>{course.label}: do zero à comunicação</h2><p>Aprenda expressões úteis e use cada frase em uma situação real.</p></div><div className="course-banner-progress"><b>{Math.round(course.lessons.filter(l=>progress.completed.includes(l.id)).length/course.lessons.length*100)}%</b><small>concluído</small></div></div>
          <div className="unit-heading"><div><span className="unit-dot"/> <span>UNIDADE 01</span><h3>{course.lessons[0].unit}</h3></div><span className="unit-count">{course.lessons.length} aulas</span></div>
          <div className="lesson-list">{course.lessons.map((l,i)=><button className={`lesson-row ${progress.completed.includes(l.id)?"done":""}`} key={l.id} onClick={()=>openLesson(l.id)}><div className={`lesson-number ${progress.completed.includes(l.id)?"complete":""}`}>{progress.completed.includes(l.id)?<Check size={19}/>:String(i+1).padStart(2,"0")}</div><div className="lesson-row-copy"><b>{l.title}</b><span>{l.goal}</span></div><div className="lesson-meta"><span><Clock3 size={14}/>{l.minutes} min</span><span className="level-pill">{l.level}</span></div><ChevronRight size={18} className="lesson-chevron"/></button>)}</div>
          <div className="info-note"><ShieldCheck size={18}/><p><b>Seu progresso fica salvo.</b> Neste aparelho, as alterações são automáticas. Para sincronizar entre dispositivos, configure o Supabase e entre na sua conta.</p></div>
        </div>}

        {view==="lesson" && lesson && <div className="page-content lesson-page">
          <button className="back-link" onClick={()=>navigate("courses")}><ArrowLeft size={16}/> Voltar ao curso</button>
          <div className="lesson-title-row"><div><div className="eyebrow">{courses[lesson.id.startsWith("en")?"en":"it"].subtitle.toUpperCase()} · {lesson.level} · LIÇÃO PRÁTICA</div><h1>{lesson.title}</h1><p className="lead">{lesson.goal}</p></div><div className="lesson-title-badge">{courses[lesson.id.startsWith("en")?"en":"it"].flag}</div></div>
          <div className="lesson-layout">
            <div className="lesson-main">
              <section className="panel learning-panel"><div className="panel-heading"><div><div className="eyebrow">01 · VOCABULÁRIO</div><h3>Palavras e expressões essenciais</h3></div><div className="panel-icon"><BookOpen size={20}/></div></div>
                <div className="word-table">{lesson.words.map(([word,meaning,pron],i)=><div className="word-row" key={word}><div className="word-index">{String(i+1).padStart(2,"0")}</div><div className="word-content"><b>{word}</b><span>{meaning}</span><small>Pronúncia aproximada: {pron}</small></div><button className="sound-btn" onClick={()=>speak(word)} aria-label={`Ouvir ${word}`}><Volume2 size={17}/></button></div>)}</div>
              </section>
              <section className="panel explanation-panel"><div className="panel-heading"><div><div className="eyebrow">02 · DICA DO PROFESSOR</div><h3>Entenda como funciona</h3></div><div className="panel-icon"><Sparkles size={20}/></div></div><p>{lesson.explanation}</p></section>
              <section className="panel dialogue-panel"><div className="panel-heading"><div><div className="eyebrow">03 · ESCUTE E REPITA</div><h3>Diálogo do dia</h3></div><button className="small-outline" onClick={()=>speak(lesson.dialogue.map(d=>d[1]).join(". "))}><Volume2 size={15}/> Ouvir diálogo</button></div><div className="dialogue-bubble-list">{lesson.dialogue.map(([speaker,line],i)=><div className={`dialogue-line ${speaker==="B"?"right":""}`} key={i}><div className={`speaker-avatar ${speaker==="B"?"alt":""}`}>{speaker}</div><div className="dialogue-bubble"><span>{speaker==="A"?"Pessoa A":"Pessoa B"}</span><p>{line}</p><button onClick={()=>speak(line)}><Volume2 size={13}/> Ouvir frase</button></div></div>)}</div><div className="practice-tip"><Mic size={17}/><span>Leia cada fala em voz alta. Depois, tente repetir sem olhar o texto.</span></div></section>
              <section className="panel quiz-panel"><div className="panel-heading"><div><div className="eyebrow">04 · TESTE SEU CONHECIMENTO</div><h3>Desafio da lição</h3></div><span className="question-count">{Object.keys(answers).length}/{lesson.questions.length} respondidas</span></div><div className="quiz-progress"><span style={{width:`${Object.keys(answers).length/lesson.questions.length*100}%`}}/></div>{lesson.questions.map((q,qi)=><div className="question-block" key={qi}><div className="question-number">QUESTÃO {String(qi+1).padStart(2,"0")}</div><h4>{q.q}</h4><div className="answer-options">{q.options.map((option,oi)=><button key={option} disabled={answers[qi]!==undefined} className={`answer-option ${answers[qi]!==undefined&&oi===q.correct?"correct":answers[qi]===oi&&oi!==q.correct?"incorrect":""}`} onClick={()=>answerQuestion(qi,oi)}><span className="option-letter">{String.fromCharCode(65+oi)}</span>{option}{answers[qi]!==undefined&&oi===q.correct&&<CheckCircle2 size={17}/>}</button>)}</div>{answers[qi]!==undefined&&<div className={`answer-feedback ${answers[qi]===q.correct?"good":"try-again"}`}><b>{answers[qi]===q.correct?"Muito bem!":"Continue praticando."}</b> {q.why}</div>}</div>)}</section>
              <div className="lesson-complete-row"><div><b>{Object.keys(answers).length===lesson.questions.length?"Você terminou o desafio!":"Faça o teste para concluir a aula"}</b><span>Você pode revisar o conteúdo antes de finalizar.</span></div><button className="primary-btn" disabled={Object.keys(answers).length!==lesson.questions.length} onClick={completeLesson}>{progress.completed.includes(lesson.id)?"Concluir novamente":"Concluir aula"} <Check size={17}/></button></div>
            </div>
            <aside className="lesson-aside"><div className="panel lesson-aside-card"><div className="aside-progress-icon"><Target size={22}/></div><h3>Objetivo da aula</h3><p>{lesson.goal}</p><div className="aside-divider"/><div className="aside-stat"><span><Clock3 size={15}/> Duração estimada</span><b>{lesson.minutes} min</b></div><div className="aside-stat"><span><Award size={15}/> Recompensa</span><b>+20 pontos</b></div><div className="aside-divider"/><button className="secondary-btn full" onClick={()=>{setTutorMode("teacher");navigate("tutor");setTutorText(`Explique para mim, em português, o conteúdo da aula “${lesson.title}”: ${lesson.explanation}`)}}><Brain size={16}/> Perguntar ao tutor</button></div><div className="aside-tip"><Sparkles size={17}/><b>Dica MAGO</b><p>Aprender é lembrar sem olhar. Depois de estudar, feche a lição e tente dizer três frases de memória.</p></div></aside>
          </div>
        </div>}

        {view==="review" && <div className="page-content">
          <section className="page-intro"><div className="eyebrow"><span className="eyebrow-line"/> MEMÓRIA DE LONGO PRAZO</div><h1>Revisão inteligente</h1><p className="lead">Reforce o que aprendeu e volte aos pontos em que precisa praticar.</p></section>
          <div className="review-summary-grid"><Stat icon={<RotateCcw size={19}/>} label="Aulas concluídas" value={`${completedCount}/${totalLessons}`} foot="Nos dois idiomas" tone="purple"/><Stat icon={<CircleHelp size={19}/>} label="Respostas dadas" value={progress.answers} foot="Questões respondidas" tone="blue"/><Stat icon={<Target size={19}/>} label="Precisão geral" value={`${accuracy}%`} foot="Acertos nas questões" tone="green"/></div>
          <section className="panel review-panel"><div className="panel-heading"><div><div className="eyebrow">RETOMADA</div><h3>Suas aulas para revisar</h3></div><RotateCcw size={20}/></div>{allLessons.filter(l=>progress.mistakes[l.id]||!progress.completed.includes(l.id)).map(l=><div className="review-row" key={l.id}><div className="review-language">{l.id.startsWith("en")?"🇬🇧":"🇮🇹"}</div><div className="review-copy"><b>{l.title}</b><span>{l.id.startsWith("en")?"Inglês":"Italiano"} · {progress.mistakes[l.id]||0} resposta(s) errada(s) registrada(s)</span></div><button className="small-outline" onClick={()=>{setLanguage(l.id.startsWith("en")?"en":"it");openLesson(l.id)}}>Revisar <ArrowRight size={14}/></button></div>)}{allLessons.every(l=>progress.completed.includes(l.id))&&<p className="success-note"><CheckCircle2 size={17}/> Você concluiu todas as aulas iniciais. Continue revisando e em breve amplie sua trilha.</p>}</section>
          <div className="info-note"><Brain size={18}/><p><b>Como funciona:</b> a versão inicial usa seus erros registrados e aulas incompletas para sugerir revisões. A programação avançada de repetição espaçada pode ser ampliada em futuras versões sem apagar seu progresso.</p></div>
        </div>}

        {view==="tutor" && <div className="page-content tutor-page">
          <section className="page-intro"><div className="eyebrow"><span className="eyebrow-line"/> SEU PARCEIRO DE APRENDIZAGEM</div><h1>Professor de IA <span className="beta-badge">BETA</span></h1><p className="lead">Faça perguntas, pratique frases e receba explicações claras em português.</p></section>
          <div className="tutor-layout"><div className="panel tutor-chat"><div className="tutor-chat-head"><div className="tutor-avatar"><Brain size={23}/></div><div><b>Professor MAGO</b><span><span className="online-dot"/> Tutor híbrido · {course.label}</span></div><span className="ai-badge">IA OPCIONAL</span></div><div className="chat-messages"><div className="chat-bubble tutor"><span>PROFESSOR MAGO</span><p>Olá! ✨ Estou aqui para ajudar você a aprender {course.label.toLowerCase()}. Você pode enviar uma frase para corrigir, pedir uma explicação ou praticar uma conversa. O tutor generativo precisa ser ativado pelo administrador do site.</p></div>{tutorReply&&<><div className="chat-bubble student"><span>VOCÊ</span><p>{tutorText}</p></div><div className="chat-bubble tutor"><span>PROFESSOR MAGO</span><p className="reply-text">{tutorReply}</p></div></>}{tutorError&&<div className="inline-error"><CircleHelp size={17}/>{tutorError}</div>}</div><form className="tutor-form" onSubmit={askTutor}><textarea value={tutorText} onChange={e=>setTutorText(e.target.value)} placeholder={`Ex.: Como digo “estou aprendendo ${course.label.toLowerCase()}” nesse idioma?`} rows={3} maxLength={1800}/><div className="tutor-form-bottom"><span>{tutorText.length}/1800 · Não envie senhas ou dados pessoais.</span><button className="primary-btn" disabled={tutorBusy||!tutorText.trim()}>{tutorBusy?"Pensando…":"Enviar pergunta"} <Send size={16}/></button></div></form></div>
            <aside className="tutor-side"><div className="panel tutor-tools"><div className="panel-heading"><div><div className="eyebrow">ESCOLHA UM TREINO</div><h3>Comece por aqui</h3></div><Settings2 size={19}/></div><button className="prompt-card" onClick={()=>setTutorText("Corrija esta frase no meu idioma de estudo, explique o erro em português e me dê um exercício: ")}><div className="prompt-icon"><CheckCircle2 size={18}/></div><span><b>Corrigir uma frase</b><small>Descubra como falar naturalmente.</small></span><ChevronRight size={17}/></button><button className="prompt-card" onClick={()=>setTutorText("Faça uma conversa de nível A1 comigo. Faça apenas uma pergunta por vez e espere minha resposta. Explique meus erros em português.")}><div className="prompt-icon"><MessageCircle size={18}/></div><span><b>Simular conversação</b><small>Uma pergunta de cada vez.</small></span><ChevronRight size={17}/></button><button className="prompt-card" onClick={()=>setTutorText("Ensine-me cinco expressões muito úteis do dia a dia. Para cada uma, dê tradução, contexto e um exercício curto.")}><div className="prompt-icon"><BookOpen size={18}/></div><span><b>Aprender expressões</b><small>Frases que você usará de verdade.</small></span><ChevronRight size={17}/></button></div><div className="ai-safety"><ShieldCheck size={19}/><b>Privacidade e transparência</b><p>Quando a IA estiver ativada, sua mensagem será enviada ao provedor configurado. Não envie dados sensíveis. Sem configuração de servidor, as lições e testes continuam disponíveis.</p></div></aside></div>
        </div>}
      </main>

      {authOpen && <div className="modal-backdrop" onClick={()=>setAuthOpen(false)}><div className="auth-modal" onClick={e=>e.stopPropagation()}><button className="modal-close icon-btn" onClick={()=>setAuthOpen(false)} aria-label="Fechar"><X size={20}/></button><div className="brand modal-brand"><div className="brand-mark"><Sparkles size={23}/></div><div><strong>MAGO <span>SUPREMO</span></strong><small>SUA JORNADA COMEÇA AQUI</small></div></div><h2>{authMode==="signup"?"Crie sua conta":authMode==="reset"?"Recuperar acesso":"Bem-vindo de volta"}</h2><p>{supabase?"Entre para sincronizar seu progresso entre dispositivos.":"Contas ainda não configuradas. Você pode continuar usando o modo local."}</p>{!supabase&&<div className="inline-error"><LockKeyhole size={17}/> Para ativar contas, configure as variáveis do Supabase e publique novamente.</div>}<form onSubmit={submitAuth} className="auth-form"><label>E-mail<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="voce@exemplo.com" autoComplete="email"/></label>{authMode!=="reset"&&<label>Senha<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} placeholder="Mínimo de 8 caracteres" autoComplete={authMode==="signup"?"new-password":"current-password"}/></label>}{authMessage&&<div className="auth-message">{authMessage}</div>}<button className="primary-btn full" disabled={authBusy}>{authBusy?"Aguarde…":authMode==="signup"?"Criar conta":authMode==="reset"?"Enviar instruções":"Entrar"} <ArrowRight size={16}/></button></form><div className="auth-switch">{authMode!=="login"&&<button onClick={()=>{setAuthMode("login");setAuthMessage("")}}>Voltar ao login</button>}{authMode==="login"&&<><button onClick={()=>{setAuthMode("signup");setAuthMessage("")}}>Criar uma conta</button><button onClick={()=>{setAuthMode("reset");setAuthMessage("")}}>Esqueci a senha</button></>}</div><div className="auth-security"><ShieldCheck size={15}/> Acesso seguro via Supabase Auth</div></div></div>}
    </div>
  );
}

function Stat({icon,label,value,foot,progress,tone="blue"}) {
  return <div className="stat-card"><div className="stat-top"><div className={`stat-icon ${tone}`}>{icon}</div><span>{label}</span></div><div className="stat-value">{value}</div>{progress!==undefined&&<div className="mini-progress"><span style={{width:`${Math.max(0,Math.min(100,progress))}%`}}/></div>}<div className="stat-foot">{foot}</div></div>;
}
function CourseCard({language,course,progress,onSelect}) {
  const done=course.lessons.filter(l=>progress.completed.includes(l.id)).length;
  const pct=Math.round(done/course.lessons.length*100);
  return <button className={`course-card ${language==="it"?"italian":""}`} onClick={onSelect}><div className="course-card-top"><div className="course-flag">{course.flag}</div><span className="level-pill">A1 · INICIANTE</span></div><h3>{course.label}</h3><p>{language==="en"?"Construa sua base e comece a conversar em inglês.":"Impara l'italiano con frasi utili e dialoghi."}</p><div className="course-progress-label"><span>{done} de {course.lessons.length} aulas</span><b>{pct}%</b></div><div className="course-progress"><span style={{width:`${pct}%`}}/></div><div className="course-card-bottom"><span><Clock3 size={14}/> 4 aulas iniciais</span><span className="course-go">Explorar <ArrowRight size={15}/></span></div></button>;
}

createRoot(document.getElementById("root")).render(<App />);
